require 'test/unit'

class ATest < Test::Unit::TestCase
  def test_something
    assert true
  end
end
